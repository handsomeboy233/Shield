from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from flask import Flask, render_template, request

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "outputs" / "final_results.csv"
SUMMARY_PATH = BASE_DIR / "outputs" / "final_results.summary.json"


def load_rows() -> List[Dict[str, Any]]:
    if not CSV_PATH.exists():
        return []
    with CSV_PATH.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        return list(csv.DictReader(f))


def load_summary(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    if SUMMARY_PATH.exists():
        try:
            with SUMMARY_PATH.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    total = len(rows)
    return {
        "total_records": total,
        "rule_hits": sum(1 for r in rows if r.get("rule_hit") == "1"),
        "anomalies": sum(1 for r in rows if r.get("is_anomaly") == "1"),
        "unknowns": sum(1 for r in rows if r.get("is_unknown") == "1"),
        "benign": sum(1 for r in rows if r.get("final_label") == "benign"),
        "anomaly_backend": rows[0].get("anomaly_model", "unknown") if rows else "none",
        "self_learning": {
            "enabled": False,
            "mode": "placeholder",
            "feedback_samples": 0,
            "rule_version": "rules-v1",
            "model_version": "model-v1",
            "last_update": "N/A",
            "note": "feedback loop reserved for later stage; current run uses fixed rules and models",
        },
    }


@app.route("/")
def index():
    rows = load_rows()
    summary = load_summary(rows)
    selected_id = request.args.get("record_id")
    stage_filter = request.args.get("stage", "all")

    filtered = rows
    if stage_filter != "all":
        filtered = [r for r in rows if r.get("stage") == stage_filter]

    selected = None
    if selected_id:
        for row in rows:
            if row.get("record_id") == selected_id:
                selected = row
                break
    if selected is None and filtered:
        selected = filtered[0]

    return render_template(
        "index.html",
        rows=filtered,
        selected=selected,
        summary=summary,
        stage_filter=stage_filter,
    )


if __name__ == "__main__":
    app.run(debug=True)
